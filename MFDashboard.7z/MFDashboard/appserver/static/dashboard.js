require(['jquery', 'splunkjs/mvc',"splunkjs/mvc/utils",'splunkjs/mvc/simplexml/ready!'], function($,mvc,utils) {
	//Highlighting selected Link Color as Yellow from Left Menu
	$("a[class=leftNavigation]").css("color", "white");
	$("a").click(function () {
		$("a[class=leftNavigation]").css("color", "white");
		$(this).css("color", "yellow");
		if($(this).text()=="")
		{$("#pageHeadingText span").text('Home');}
		else
		{$("#pageHeadingText span").text($(this).text());}
    });

    $(document).ready(function() {
	  function setHeight() {
	    windowHeight = $(window).innerHeight();
	    $("#tblLeftMenu").css("height", windowHeight);
	  };
	  setHeight();

	  $(window).resize(function() {
	      setHeight();
 		 });

	});

	if(window.location.pathname=='/en-US/app/MFDashboard/home')
	{

			 $(document).ajaxComplete( function() {
				 $("thead").remove();
				 $("tr:nth-child(even)>td").css("background-color", "white");
			 });
	}

	//Overwrite the utils.redirect to open new window as popup
	utils.redirect=	function(e,t,n){
		var w = 1100;
        var h = 350;
        var left = Number((screen.width/2)-(w/2));
        var top = Number((screen.height/2)-(h/2));
		var winOpt = 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no width='+w+', height='+h+', top='+top+', left='+left;
		t?window.open(e,"_blank", winOpt):n?window.open(e,n,winOpt):window.location=e;
	};

	//Overwrite the Date Object to include
	//Add a property for GetFirstDayOfPreviousWeek from the Date objects
	Date.prototype.GetFirstDayOfPreviousWeek = function() {
		return (new Date(this.getFullYear(), this.getMonth(), this.getDate() - (this.getDay()+7) ) );
	}
	//Add a property for GetLastDayOfPreviousWeek from the Date objects
	Date.prototype.GetLastDayOfPreviousWeek = function() {
		return (new Date(this.getFullYear(), this.getMonth(), this.getDate() - (this.getDay()+1)  ));
	}
	var today = new Date();
	var monthNum = today.getMonth();
	var yearNum = today.getFullYear();
	var lastWeekText = null;
	var LastMonthText = null;
	var PreviousMonthText = null;

	//Form text with Last Week start & end Date
	var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
	if(today.GetFirstDayOfPreviousWeek().getMonth()==today.GetLastDayOfPreviousWeek().getMonth()){
		lastWeekText =  "(" + monthNames[today.GetFirstDayOfPreviousWeek().getMonth()] + ' '
						+ today.GetFirstDayOfPreviousWeek().getDate()  + ' - '
						+ today.GetLastDayOfPreviousWeek().getDate() + ")";
	}
	else{
		lastWeekText =  "(" + monthNames[today.GetFirstDayOfPreviousWeek().getMonth()] + '/'
						+ today.GetFirstDayOfPreviousWeek().getDate()  + ' - '
						+ monthNames[today.GetLastDayOfPreviousWeek().getMonth()] + '/'
						+ today.GetLastDayOfPreviousWeek().getDate() + ")";
	}
	//Form text for month with year
	if(monthNum==0){//month is January
		LastMonthText = monthNames[11] + '-' + (yearNum-1);	//December
		PreviousMonthText = monthNames[10] + '-' + (yearNum-1); //November
	}else if(monthNum==1){//month is February
		LastMonthText = monthNames[monthNum-1] + '-' + yearNum;	//January
		PreviousMonthText = monthNames[11] + '-' + (yearNum-1); //December
	}else{
		LastMonthText = monthNames[monthNum-1] +'-' + yearNum;
		PreviousMonthText = monthNames[monthNum-2]+'-' + yearNum;
	}

	//Set default Token Values to use in Search queries
	var tokens = mvc.Components.get('default');
	tokens.set('LastWeekText', lastWeekText);
	tokens.set('LastMonth', LastMonthText);
	tokens.set('PreviousMonth', PreviousMonthText);
	tokens.set('WindowHeight', $(window).height());

	//var submittedTokens = mvc.Components.get('submitted');
	//submittedTokens.set('LastWeek', lastWeekText);



	/*
	//Add a submit button near by text box input
	var r= $('<input type="submit" class="submit" value="Submit"/>');
	$("#input1_2261").width($("#input1_2261").width()+100);
    $("#input1_2261").append(r);
	*/

	/*
	//Custom panel width by run time based on number of panels in a row
	// Grab the DOM for the dashboard row
	//var firstRow = $('.dashboard-row').first();

	var secondRow = $($('.dashboard-row2')).children('.dashboard-cell');
	pageAlign(secondRow.length,secondRow);

	var thirdRow = $($('.dashboard-row3')).children('.dashboard-cell');
	pageAlign(thirdRow.length,thirdRow);

	var fourthRow = $($('.dashboard-row4')).children('.dashboard-cell');
	pageAlign(fourthRow.length,fourthRow);

	// Adjust the cells' width
	function pageAlign(panelCellLenth,objPanelCells){
		switch(panelCellLenth)
		{
			case 0:
				$(objPanelCells[0]).css('width', '100%');
				break;
			case 1:
				$(objPanelCells[1]).css('width', '100%');
				break;
			case 2:
				$(objPanelCells[1]).css('width', '50%');
				$(objPanelCells[2]).css('width', '50%');
				break;
			default:
				$(objPanelCells[0]).css('width', '100%');
		}
		//alert('case - '+panelCellLenth);
		// Force visualizations (esp. charts) to be redrawn with their new size
		$(window).trigger('resize');
	}
	*/
});
